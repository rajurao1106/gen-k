"use client";

import { usePathname, useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { BottomNav, Sidebar } from "./components/Sidebar";
import type { PageKey } from "./types";
import KundaliPage from "./features/KundaliPage";
import KundaliMilanPage from "./features/KundaliMilanPage";
import NumerologyPage from "./features/NumerologyPage";
import MahadashaPage from "./features/MahadashaPage";
import LoginPage from "./features/LoginPage";
import UserDataPage from "./features/UserDataPage";
import AIFriendPage from "./features/AIFriendPage";

const PAGE_TITLES: Record<PageKey, { hi: string; sub: string }> = {
  home: { hi: "Home", sub: "Introduction & quick access" },
  kundali: { hi: "कुंडली", sub: "Personalized life reading" },
  "ai-friend": { hi: "AI Friend", sub: "Your personal voice companion" },
  milan: { hi: "कुंडली मिलान", sub: "Ashtakoot compatibility match" },
  numerology: { hi: "न्यूमरोलॉजी", sub: "Name & birth-number reading" },
  mahadasha: { hi: "महादशा", sub: "Vimshottari dasha timeline & outlook" },
};

const PAGE_ROUTES: Record<PageKey, string> = {
  home: "/dashboard",
  kundali: "/kundali",
  "ai-friend": "/ai-friend",
  milan: "/milan",
  numerology: "/numerology",
  mahadasha: "/mahadasha",
};

function HomeIntroPage() {
  const router = useRouter();
  const cards = [
    {
      label: "कुंडली",
      desc: "Birth details, chart reading & guidance",
      path: "/kundali",
    },
    {
      label: "कुंडली मिलान",
      desc: "Compatibility matching & guna analysis",
      path: "/milan",
    },
    {
      label: "न्यूमरोलॉजी",
      desc: "Name and number-based insights",
      path: "/numerology",
    },
    {
      label: "महादशा",
      desc: "Timeline and major life phases",
      path: "/mahadasha",
    },
    {
      label: "AI Friend",
      desc: "Ask questions and explore your chart",
      path: "/ai-friend",
    },
  ];

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-[#f2c36b]/20 bg-[#10273d]/80 p-5 shadow-[0_20px_40px_rgba(0,0,0,0.18)] sm:p-6">
        <p className="text-xs uppercase tracking-[0.22em] text-[#f2c36b]">
          Welcome
        </p>
        <h2 className="mt-3 font-display text-2xl font-bold text-[#f9f3eb] sm:text-3xl">
          Gen-K Astrology
        </h2>
        <p className="mt-3 max-w-2xl text-sm leading-6 text-[#d9e5f7] sm:text-base">
          Your spiritual companion for kundali insights, love compatibility,
          numerology and mahadasha guidance.
        </p>
      </div>

      <div className="grid gap-3 sm:gap-4 md:grid-cols-2 xl:grid-cols-3">
        {cards.map((card) => (
          <button
            key={card.label}
            type="button"
            onClick={() => router.push(card.path)}
            className="group min-h-36 rounded-2xl border border-[#f2c36b]/25 bg-[#0d2138]/80 p-4 text-left transition-all hover:-translate-y-0.5 hover:border-[#f2c36b]/60 hover:shadow-[0_0_20px_rgba(248,210,122,0.12)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#f2c36b] sm:min-h-40 sm:p-5"
          >
            <p className="font-display text-xl font-semibold text-[#f8d27a] transition-colors group-hover:text-[#ffdf9a] sm:text-2xl">
              {card.label}
            </p>
            <p className="mt-2 text-sm leading-5 text-[#d9e5f7] sm:leading-6">
              {card.desc}
            </p>
            <span className="mt-4 inline-flex items-center gap-1 text-xs font-semibold uppercase tracking-wide text-[#f8d27a]">
              Open page →
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}

const isAdminAuthenticated = () => {
  if (typeof window === "undefined") return false;
  return localStorage.getItem("genk_admin_session") === "true";
};

function KundaliExperience() {
  const router = useRouter();
  const pathname = usePathname();
  const page = useMemo<PageKey>(() => {
    switch (pathname) {
      case "/milan":
        return "milan";
      case "/numerology":
        return "numerology";
      case "/mahadasha":
        return "mahadasha";
      case "/kundali":
        return "kundali";
      case "/ai-friend":
        return "ai-friend";
      default:
        return "home";
    }
  }, [pathname]);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div
      id="appShell"
      className="relative min-h-screen bg-[var(--bg-app)] text-[var(--text-primary)] overflow-x-clip"
    >
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Rajdhani:wght@500;600;700&family=Mukta:wght@400;500;600;700&display=swap');

        :root {
          --bg-app: #071a2a;
          --bg-surface: #10273d;
          --bg-surface-strong: #153555;
          --bg-surface-soft: #1d446d;
          --bg-header: #0d2138;
          --gold: #f0c06d;
          --gold-strong: #d69b3c;
          --gold-soft: #f8e6b6;
          --text-primary: #f9f3eb;
          --text-body: #edf2fb;
          --text-muted: #c9d8ed;
          --text-subtle: #a6bddb;
          --text-dark: #081724;
          --border: rgba(240,192,109,0.34);
          --danger: #ef9f90;
        }

        .font-display { font-family: 'Rajdhani', sans-serif; letter-spacing: 0.01em; }
        .font-body { font-family: 'Mukta', sans-serif; }

        .brass-surface {
          background:
            radial-gradient(circle at 15% 20%, rgba(240,192,109,0.14), transparent 42%),
            radial-gradient(circle at 85% 80%, rgba(120,170,255,0.08), transparent 48%),
            linear-gradient(160deg, #0a1d2f 0%, #0d233b 45%, #071822 100%);
        }
        .brass-header {
          background: linear-gradient(135deg, #10273d 0%, #0d2138 52%, #0a1a2e 100%);
        }

        .prose-kundli h2 { font-family: 'Rajdhani', sans-serif; color: var(--gold); font-size: 1.5rem; font-weight: 700; margin-top: 2rem; margin-bottom: 0.75rem; border-bottom: 1px solid var(--border); padding-bottom: 0.4rem; }
        .prose-kundli h1 { font-family: 'Rajdhani', sans-serif; color: var(--text-primary); font-size: 2rem; font-weight: 700; margin-bottom: 1rem; }
        .prose-kundli h3 { color: var(--gold-soft); font-size: 1.05rem; font-weight: 600; margin-top: 1.25rem; margin-bottom: 0.4rem; }
        .prose-kundli p { color: var(--text-body); line-height: 1.7; margin-bottom: 0.85rem; }
        .prose-kundli ul { color: var(--text-body); margin-bottom: 0.85rem; padding-left: 1.1rem; }
        .prose-kundli li { margin-bottom: 0.35rem; }
        .prose-kundli li::marker { color: var(--gold); }
        .prose-kundli strong { color: var(--text-primary); }
        .prose-kundli table { display: block; max-width: 100%; overflow-x: auto; border-collapse: collapse; margin-bottom: 1rem; -webkit-overflow-scrolling: touch; border: 1px solid var(--border); border-radius: 8px; }
        .prose-kundli th, .prose-kundli td { border: 1px solid rgba(216,179,106,0.18); padding: 0.55rem 0.8rem; text-align: left; color: var(--text-body); white-space: nowrap; }
        .prose-kundli th { color: var(--text-dark); background: var(--gold); font-weight: 700; }
        .prose-kundli tr:nth-child(even) td { background: rgba(216,179,106,0.05); }
        .prose-kundli h1, .prose-kundli h2, .prose-kundli h3, .prose-kundli p, .prose-kundli li {
          overflow-wrap: break-word;
          word-break: break-word;
        }
        input[type="date"], input[type="time"] { color-scheme: dark; }
html, body { max-width: 100%; overflow-x: clip; }
        * { min-width: 0; }

        @page {
          size: A4 portrait;
          margin: 12mm;
        }

        @media print {
          html, body, #root {
            height: auto !important;
            overflow: visible !important;
            background: #ffffff !important;
          }
          body { background: #ffffff !important; }
          #appShell {
            position: static !important;
            display: block !important;
            height: auto !important;
            min-height: 0 !important;
            overflow: visible !important;
            background: #ffffff !important;
          }

          .no-print { display: none !important; }

          #printArea {
            display: block !important;
            position: static !important;
            width: auto !important;
            max-width: none !important;
            min-height: 0 !important;
            height: auto !important;
            overflow: visible !important;
            background: #ffffff !important;
            color: #111111 !important;
            box-shadow: none !important;
            border: none !important;
            margin: 0 !important;
            padding: 0 !important;
            page-break-inside: auto;
            break-inside: auto;
          }

          #printArea .prose-kundli {
            display: block !important;
            width: 100% !important;
            max-width: none !important;
            overflow: visible !important;
            color: #111111 !important;
          }

          #printArea .prose-kundli h2 { color: #8a5410; }
          #printArea .prose-kundli p,
          #printArea .prose-kundli ul,
          #printArea .prose-kundli li,
          #printArea .prose-kundli th,
          #printArea .prose-kundli td { color: #111111; }
          #printArea .prose-kundli strong { color: #000000; }
          #printArea .prose-kundli h2,
          #printArea .prose-kundli h3,
          #printArea .prose-kundli p,
          #printArea .prose-kundli ul,
          #printArea .prose-kundli li,
          #printArea table,
          #printArea th,
          #printArea td {
            break-inside: auto;
            page-break-inside: auto;
          }
          #printArea table {
            display: table !important;
            width: 100% !important;
            max-width: 100% !important;
            overflow: visible !important;
            table-layout: auto;
          }
        }
      `}</style>

      <div className="absolute inset-0 brass-surface pointer-events-none no-print" />

      <div className="relative lg:flex lg:items-start lg:min-h-screen">
        <Sidebar
          open={menuOpen}
          onClose={() => setMenuOpen(false)}
          activePage={page}
          onNavigate={(nextPage) => router.push(PAGE_ROUTES[nextPage])}
        />

        <BottomNav
          activePage={page}
          onNavigate={(nextPage) => router.push(PAGE_ROUTES[nextPage])}
          onOpenMenu={() => setMenuOpen(true)}
        />

        <div className="min-w-0 flex-1 ">
          <header className="relative lg:hidden brass-header border-b border-[#f2c36b]/25 no-print">
            <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-4 flex items-center gap-3">
              {/* <div className="h-9 w-9 rounded-lg overflow-hidden bg-[#f2c36b] flex items-center justify-center text-[#0b1324] font-display font-bold text-lg shrink-0">
                <img src="/logo.png" alt="" />
              </div> */}
              <div>
                {page === "home" ? (
                  <h1 className="font-display text-lg font-semibold tracking-wide text-[#f5efe6] sm:text-xl">
                    Gen-K &middot; {PAGE_TITLES[page].hi}
                  </h1>
                ) : (
                  <p className="font-display text-lg font-semibold tracking-wide text-[#f5efe6] sm:text-xl">
                    Gen-K &middot; {PAGE_TITLES[page].hi}
                  </p>
                )}
                <p className="text-[10px] sm:text-xs text-[#afbdd7] tracking-wide">
                  {PAGE_TITLES[page].sub}
                </p>
              </div>
            </div>
          </header>

          <div className="relative mx-auto max-w-6xl px-4 pb-28 pt-8 font-body sm:px-6 lg:px-8 lg:pb-8">
            {page === "home" && <HomeIntroPage />}
            {page === "kundali" && <KundaliPage />}
            {page === "ai-friend" && <AIFriendPage />}
            {page === "milan" && <KundaliMilanPage />}
            {page === "numerology" && <NumerologyPage />}
            {page === "mahadasha" && <MahadashaPage />}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const pathname = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (pathname === "/user-data" && !isAdminAuthenticated()) {
      router.replace("/login");
    }
  }, [pathname, router]);

  if (pathname === "/login") return <LoginPage />;
  if (pathname === "/user-data") {
    return isAdminAuthenticated() ? <UserDataPage /> : null;
  }
  return <KundaliExperience />;
}